Pasos
1.- Abrir el proyecto Automatización 1
2.- Luego seleccionar el package de runners
3.- Seleccionar la clase RunLogin.java
4.- Darle play a la flecha verde que aparece en el lado izquierdo en el Intellij public class RunLogin
